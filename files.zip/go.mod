module github.com/yourname/embedserver

go 1.22

require (
	github.com/google/uuid v1.6.0
	github.com/ledongthuc/pdf v0.0.0-20240201131950-da5b75280b06
	github.com/nguyenthenguyen/docx v0.0.0-20230621112118-9c8e795a11db
	github.com/qdrant/go-client v1.11.0
	google.golang.org/grpc v1.66.0
)
